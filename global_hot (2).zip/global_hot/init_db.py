import sqlite3

def init_db():
    conn = sqlite3.connect('obsidianweb.db')
    cursor = conn.cursor()

    # 1. Таблица пользователей
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        email TEXT,
        password_hash TEXT,
        role TEXT DEFAULT 'User',
        status TEXT DEFAULT 'Active',
        sub_days TEXT DEFAULT '30'

    )
    ''')

    # 2. Таблица сообщений чата
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user TEXT,
        msg TEXT,
        role TEXT,
        color TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    # 3. Таблица инвайтов
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS invites (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE,
        status TEXT DEFAULT 'active' -- 'active' или 'used'
    )
    ''')

    # Добавим тестовый инвайт для проверки
    cursor.execute("INSERT OR IGNORE INTO invites (code) VALUES ('OBSIDIAN-TEST-123')")

    conn.commit()
    conn.close()
    print("✅ База Obsidian настроена: 3 таблицы готовы.")

init_db()