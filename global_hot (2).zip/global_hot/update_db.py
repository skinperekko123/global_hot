import sqlite3

db_name = 'obsidianweb.db' 
import sqlite3

def create_cloud_radar_plan():
    try:
        conn = sqlite3.connect('obsidianweb.db') 
        cursor = conn.cursor()
        
        # 1. Проверяем по системному ID (cloud_radar), а не по красивому названию
        cursor.execute("SELECT id FROM plans WHERE plan_id = ?", ('cloud_radar',))
        
        if cursor.fetchone() is None:
            # 2. Убираем ручную вставку 'id' (пусть БД сама ставит 1, 2, 3...)
            # 3. Проверь, чтобы названия колонок в скобках точно совпадали с твоей БД
            cursor.execute("""
                INSERT INTO plans (plan_id, display_name, price, days) 
                VALUES (?, ?, ?, ?)
            """, ('cloud_radar', 'Cloud Radar', 6000, 30))
            
            conn.commit()
            print("План 'Cloud Radar' успешно добавлен!")
        else:
            print("План уже существует.")
            
        conn.close()
    except Exception as e:
        # Это выведет точный текст ошибки (например, что колонки 'days' не существует)
        print(f"Ошибка при работе с БД: {e}")

# Вызови функцию один раз
# create_cloud_radar_plan()
def update():
    conn = sqlite3.connect(db_name)
    cursor = conn.cursor()
    
    # 1. Пробуем добавить колонку (отдельно)
    try:
        cursor.execute('ALTER TABLE users ADD COLUMN hide_invested ')
        print("✅ Колонка created_at успешно добавлена.")
    except sqlite3.OperationalError:
        print("ℹ️ Колонка created_at уже существует.")
    except Exception as e:
        print(f"❌ Ошибка при добавлении колонки: {e}")

    # 2. Пробуем добавить промокод
    try:
        # Убедись, что таблица promocodes существует, прежде чем вставлять данные
        cursor.execute("INSERT OR IGNORE INTO promocodes (code, discount_percent, uses_left) VALUES (?, ?, ?)", 
                       ('OBSIDIAN2026', 15, 100))
        print("✅ Промокод проверен/добавлен.")
    except Exception as e:
        print(f"❌ Ошибка при работе с промокодами: {e}")

    conn.commit()
    conn.close()
def init_announcements():
    db_name = "obsidianweb.db" # Убедись, что имя совпадает с твоим
    conn = sqlite3.connect(db_name)
    cursor = conn.cursor()
    
    # 1. Создаем таблицу объявлений
    try:
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS announcements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT,
                content TEXT NOT NULL,
                image_url TEXT,         -- Добавили
                date DATETIME DEFAULT CURRENT_TIMESTAMP,
                author_id INTEGER,      -- Добавили
                author TEXT DEFAULT 'Admin'
            )
        ''')
        print("✅ Таблица announcements проверена/создана.1й2")
    except Exception as e:
        print(f"❌ Ошибка при создании таблицы announcements: {e}")

    # 2. Добавляем приветственное сообщение (если таблица пуста)
    

    conn.commit()
    conn.close()

if __name__ == "__main__":
    create_cloud_radar_plan()
    update()
    init_announcements()
