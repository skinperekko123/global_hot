const searchInput = document.getElementById('userSearchInput');
const resultsBox = document.getElementById('searchResults');

if (searchInput) {
    searchInput.addEventListener('input', async () => {
        const query = searchInput.value;

        if (query.length < 2) {
            resultsBox.style.display = 'none';
            return;
        }

        const response = await fetch(`/api/search?query=${query}`);
        const users = await response.json();

        if (users.length > 0) {
            resultsBox.innerHTML = users.map(user => {
                let roleClass;
                const role = user.role.toLowerCase();

                if (role === 'owner') roleClass = 'user-owner';
                else if (role === 'coder') roleClass = 'user-coder';
                else if (role === 'admin') roleClass = 'user-admin';
                else roleClass = 'user-default';

                return `
                    <a href="/profile/${user.id}" class="search-item" style="display: block; padding: 12px; border-bottom: 1px solid #1a1a1a; text-decoration: none;">
                        <div class="${roleClass}" style="font-size: 1em;">${user.username}</div>
                        <div style="color: #444; font-size: 0.6em; text-transform: uppercase;">${user.role}</div>
                    </a>
                `;
            }).join('');
            resultsBox.style.display = 'block';
        } else {
            resultsBox.innerHTML = '<div style="padding: 10px; color: #444; font-size: 0.8em;">Not found</div>';
            resultsBox.style.display = 'block';
        }
    });

    // Закрываем поиск, если кликнули мимо
    document.addEventListener('click', (e) => {
        if (!searchInput.contains(e.target) && !resultsBox.contains(e.target)) {
            resultsBox.style.display = 'none';
        }
    });
}

