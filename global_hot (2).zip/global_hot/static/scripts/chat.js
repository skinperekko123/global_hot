document.addEventListener('DOMContentLoaded', () => {
    // ВАЖНО: Мы не создаем тут новый socket, а берем тот, что в base.html
    // Если в консоли ошибка "socket is not defined", раскомментируй строку ниже:
    // const socket = io(); 

    const chatBox = document.getElementById('chat-box');
    const messageInput = document.getElementById('user-message');
    const onlineBox = document.getElementById('online-users-box');

    // 1. Автопрокрутка
    const scrollToBottom = () => {
        if (chatBox) {
            requestAnimationFrame(() => {
                chatBox.scrollTop = chatBox.scrollHeight;
            });
        }
    };

    const observer = new MutationObserver(scrollToBottom);
    if (chatBox) {
        observer.observe(chatBox, { childList: true, subtree: true });
        setTimeout(scrollToBottom, 50);
        setTimeout(scrollToBottom, 300);
    }

    // 2. Функция отправки (с проверкой на наличие инпута)
    window.sendMessage = () => {
        if (messageInput) {
            const message = messageInput.value.trim();
            if (message !== "") {
                socket.emit('send_message', { message: message });
                messageInput.value = '';
            }
        }
    };

    // 3. Отправка по Enter (ПРОВЕРКА НА NULL)
    if (messageInput) {
        messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') sendMessage();
        });
    }

    // 4. Новые сообщения
    socket.on('receive_message', (data) => {
        if (chatBox) {
            const msgDiv = document.createElement('div');
            msgDiv.className = 'message';
            msgDiv.style.marginBottom = '8px';
            msgDiv.innerHTML = `
                <span class="role-badge" style="color: ${data.color}; font-size: 0.7em; text-transform: uppercase; border: 1px solid ${data.color}33; padding: 1px 4px; margin-right: 5px;">
                    ${data.role || 'User'}
                </span>
                <b style="color: ${data.color || 'chartreuse'}">${data.user}:</b> 
                <span style="color: #ccc;">${data.msg}</span>
            `;
            chatBox.appendChild(msgDiv);
            scrollToBottom();
        }
    });

    // 5. ОБРАБОТКА ОНЛАЙН-СПИСКА
    socket.on('update_online_list', function(users) {
        const onlineBox = document.getElementById('online-users-box');
        if (onlineBox) {
            onlineBox.innerHTML = ''; 

            // СОРТИРОВКА: Овнеры и Кодеры вперед
            const sortedUsers = [...users].sort((a, b) => {
                const getPriority = (role) => {
                    const r = (role || '').toUpperCase();
                    if (r === 'OWNER') return 1;
                    if (r === 'CODER' || r === 'ADMIN') return 2;
                    return 3; // Обычные юзеры
                };
                return getPriority(a.role) - getPriority(b.role);
            });

            sortedUsers.forEach(user => {
                const role = (user.role || 'USER').toUpperCase();
                let color = '#d97706'; 
                
                if (role === 'OWNER') color = 'gold';
                else if ( role === 'CODER') color = '#ff4444';
                else if (role === 'PIKMI') color = 'pink';
                else if (role === 'ADMIN') color = 'cyan';

                // Внутри цикла users.forEach(user => { ... })

                const userTag = document.createElement('div');
                userTag.style.cssText = "background: white; border: 1px solid #ced4da; padding: 5px 12px; border-radius: 4px; display: flex; align-items: center; gap: 8px; cursor: pointer; transition: 0.2s; color: #ced4da; box-shadow: 0 1px 3px rgba(0,0,0,0.05);";

                // Добавляем эффект при наведении
                userTag.onmouseover = () => { userTag.style.borderColor = color; };
                userTag.onmouseout = () => { userTag.style.borderColor = '#ced4da'; };

                // Формируем внутренность с ссылкой на профиль
                userTag.innerHTML = `
                    <a href="/profile/${user.id}" style="text-decoration: none; display: flex; align-items: center; gap: 8px; width: 100%;">
                        <div style="width: 7px; height: 7px; background: ${color}; border-radius: 50%; box-shadow: 0 0 8px ${color}CC;"></div>
                        <span style="color: ${color}; font-size: 0.75em; letter-spacing: 2px;">
                            ${user.username}
                        </span>
                    </a>
                `;

                onlineBox.appendChild(userTag);
            });
        }

        // Обновление статуса в профиле
        const statusElement = document.getElementById('profile-status');
        if (statusElement) {
            const profileUserId = window.CURRENT_PROFILE_ID; 
            if (profileUserId) {
                const isOnline = users.some(u => String(u.id) === String(profileUserId));
                if (isOnline) {
                    statusElement.innerText = "ONLINE";
                    statusElement.style.color = "#adff2f";
                    statusElement.style.textShadow = "0 0 8px #adff2fCC";
                } else {
                    statusElement.innerText = "OFFLINE";
                    statusElement.style.color = "#666";
                    statusElement.style.textShadow = "none";
                }
            }
        }
    });

    socket.on('connect', () => console.log("Connected to Obsidian Network"));
});