const basePrice = window.initialPrice || 0;
const finalAmountDisplay = document.getElementById('finalAmount');
const promoMsg = document.getElementById('promoMsg');
const payButton = document.querySelector('.buy-button');

// 1. Логика промокода (оставляем как была, она рабочая)
async function applyPromo() {
    const codeInput = document.getElementById('promoInput').value.trim();
    if (!codeInput) {
        finalAmountDisplay.innerText = basePrice;
        promoMsg.innerText = "";
        return;
    }
    try {
        const response = await fetch(`/api/check_promo?code=${codeInput}`);
        const data = await response.json();
        if (data.success) {
            let discount = Number(data.discount);
            let finalPrice = Math.floor(basePrice * (1 - (discount / 100)));
            finalAmountDisplay.innerText = finalPrice;
            promoMsg.style.color = 'chartreuse';
            promoMsg.innerText = `ПРОМОКОД ПРИМЕНЕН: -${discount}%`;
        } else {
            finalAmountDisplay.innerText = basePrice;
            promoMsg.style.color = '#ff4444';
            promoMsg.innerText = data.message;
        }
    } catch (e) {
        console.error("Ошибка API промокода:", e);
    }
}

// 2. ИСПРАВЛЕННАЯ ЛОГИКА PAY
if (payButton) {
    payButton.onclick = async function(event) {
        if (event) event.preventDefault();
        
        console.log("Кнопка нажата...");

        const currentPrice = parseInt(finalAmountDisplay.innerText) || basePrice;
        const codeInput = document.getElementById('promoInput').value.trim();
        
        // --- НОВАЯ ЛОГИКА: СКРЫВАЕМ КНОПКУ ---
        // 1. Создаем контейнер для надписи
        const loader = document.createElement('div');
        loader.id = "processing-msg";
        loader.innerHTML = `
            <div style="text-align: center; padding: 15px; border: 1px dashed #adff2f; background: rgba(173, 255, 47, 0.05);">
                <span style="color: #adff2f; font-weight: bold; text-transform: uppercase; letter-spacing: 1px;">
                    ⏳ Заказ в обработке...
                </span>
                <p style="color: #666; font-size: 0.7em; margin-top: 5px; margin-bottom: 0;">Перенаправляем на шлюз оплаты</p>
            </div>
        `;

        // 2. Скрываем кнопку и вставляем надпись
        payButton.style.display = 'none';
        payButton.parentNode.appendChild(loader);
        // ---------------------------------------

        try {
            console.log("Отправка заказа в базу...");
            const response = await fetch('/api/create_order', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    plan: window.currentPlan,
                    price: currentPrice,
                    promo: codeInput
                })
            });

            const result = await response.json();
            console.log("Ответ сервера:", result);

            if (result.success) {
                console.log("Успех, перенаправляем...");
                // Даем небольшую задержку (800мс), чтобы юзер успел увидеть надпись
                setTimeout(() => {
                    const donateUrl = `https://donatepay.ru/don/1440492?amount=${currentPrice}&content=ID${window.userId}_${window.currentPlan}`;
                    window.location.href = donateUrl;
                }, 800);
            } else {
                alert("Ошибка сервера: " + (result.message || "Неизвестная ошибка"));
                showBtnAgain(); // Возвращаем кнопку, если ошибка
            }
        } catch (e) {
            console.error("Критическая ошибка:", e);
            alert("Ошибка соединения с сервером.");
            showBtnAgain(); // Возвращаем кнопку, если ошибка
        }
    };
}

// Функция для возврата кнопки, если что-то пошло не так
function showBtnAgain() {
    const loader = document.getElementById('processing-msg');
    if (loader) loader.remove();
    payButton.style.display = 'block';
    payButton.innerText = "PAY";
    payButton.disabled = false;
}