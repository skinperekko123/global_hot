window.addEventListener('load', function() {
    const loader = document.getElementById('loader-wrapper');
    
    // Проверяем, есть ли в памяти браузера пометка "was_loaded"
    if (!sessionStorage.getItem('was_loaded')) {
        
        // СЛУЧАЙ 1: Первый заход (лоадер висит 3 секунды)
        setTimeout(() => {
            if (loader) {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                }, 500);
            }
            // Ставим метку, что лоадер уже был показан
            sessionStorage.setItem('was_loaded', 'true');
        }, 3000);

    } else {
        // СЛУЧАЙ 2: Повторный заход или редирект (убираем лоадер мгновенно)
        if (loader) {
            loader.style.display = 'none';
        }
    }
});
const overlay = document.getElementById('overlay-bar');
let isDragging = false;
let offset = [0, 0];

// 1. ПРИ ЗАГРУЗКЕ: Восстанавливаем позицию из памяти
window.onload = () => {
    const savedX = localStorage.getItem('overlayX');
    const savedY = localStorage.getItem('overlayY');
    if (savedX && savedY) {
        overlay.style.left = savedX + 'px';
        overlay.style.top = savedY + 'px';
    }
};

overlay.addEventListener('mousedown', (e) => {
    isDragging = true;
    overlay.style.cursor = 'grabbing';
    offset = [overlay.offsetLeft - e.clientX, overlay.offsetTop - e.clientY];
}, true);

document.addEventListener('mouseup', () => { 
    isDragging = false; 
    overlay.style.cursor = 'grab';
    
    // 2. ПРИ ОТПУСКАНИИ: Сохраняем финальную позицию
    localStorage.setItem('overlayX', overlay.offsetLeft);
    localStorage.setItem('overlayY', overlay.offsetTop);
}, true);

document.addEventListener('mousemove', (e) => {
    if (isDragging) {
        overlay.style.left = (e.clientX + offset[0]) + 'px';
        overlay.style.top = (e.clientY + offset[1]) + 'px';
    }
}, true);

// --- ЛОГИКА ЧАСОВ ---
setInterval(() => {
    const now = new Date();
    document.getElementById('clock').innerText = now.toLocaleTimeString('ru-RU', {hour12: false});
}, 1000);

// --- ЛОГИКА FPS (Браузерный метод) ---
let frameCount = 0;
let lastTime = performance.now();
const fpsDisplay = document.getElementById('fps');

function updateFPS() {
    frameCount++;
    const now = performance.now();
    if (now - lastTime >= 1000) {
        fpsDisplay.innerText = frameCount;
        frameCount = 0;
        lastTime = now;
    }
    requestAnimationFrame(updateFPS);
}
requestAnimationFrame(updateFPS);