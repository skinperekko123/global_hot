from flask import Flask, request, session, render_template, redirect, url_for, send_from_directory, flash, Response, abort
from flask_socketio import SocketIO, emit
from werkzeug.security import generate_password_hash, check_password_hash # ДЛЯ БЕЗОПАСНОСТИ
import os
import requests
import smtplib
import random
from markupsafe import escape
from email.mime.text import MIMEText
from  sender import send_verification_code
import sqlite3
from flask import jsonify
import string
from datetime import datetime, timedelta # Импортируем сразу класс

from werkzeug.utils import secure_filename

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# Переменная, которая указывает на твою папку с файлами
INTERNAL_DIR = os.path.join(BASE_DIR, 'internal_files')
EXTERNAL_DIR = os.path.join(BASE_DIR, 'external_files')
ARNOLD_DIR = os.path.join(BASE_DIR, 'arnold_files')
AVATAR_FOLDER = 'static/uploads/avatars'
os.makedirs(AVATAR_FOLDER, exist_ok=True)




app = Flask(__name__)
app.secret_key = 'obsidian_secure_key_1337'
UPLOAD_FOLDER = 'static/uploads/posts'
# Разрешенные расширения
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Создаем папку, если её нет
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS




def get_db_connection():
    # Мы подключаемся к файлу, который ты только что создал
    conn = sqlite3.connect('obsidianweb.db')
    conn.row_factory = sqlite3.Row # Это позволит обращаться к колонкам по именам, а не индексам
    return conn


# Инициализируем сокеты с поддержкой CORS (чтобы браузер не блокировал запросы)
socketio = SocketIO(app, cors_allowed_origins="*", manage_session=True)



@app.route("/")
def main_page():
    # Если в сессии есть ID пользователя, значит он уже залогинен
    user_id = session.get('user_id')
    
    if user_id:
        print(f"[DEBUG] Юзер {session.get('username')} уже авторизован. Редирект в кабинет.")
        return redirect(url_for('obsidian', id=user_id))
    
    # Если не залогинен — показываем регистрацию
    return render_template("register.html", role=session.get('role'))

@app.route('/register', methods=['POST'])
def register():
    # .strip() убирает случайные пробелы по краям
    # Убедись, что в HTML name="invitecode"
    invite = request.form.get('invitecode', '').strip()
    username = request.form.get('username', '').strip()
    email = request.form.get('email', '').strip()
    password = request.form.get('password')
    confirm_pw = request.form.get('confirm_password')
    browser_id = request.form.get('browser_id')
    print("--- DEBUG REGISTRATION ---")
    print(f"1. Получен инвайт из формы: '{invite}'")
    print(f"2. Длина инвайта: {len(invite)}")

    # Проверим, что вообще есть в таблице инвайтов (для теста)
    test_conn = get_db_connection()
    all_invites = test_conn.execute('SELECT code, status FROM invites').fetchall()
    test_conn.close()

    print("3. Список всех инвайтов в БД:")
    for inv in all_invites:
        print(f"   Код: '{inv['code']}', Статус: '{inv['status']}'")
    print("--------------------------")


    # 1. Проверка на пустые поля (чтобы не упало дальше)
    if not invite or not username or not email:
        flash("All fields are required!")
        return redirect(url_for('main_page'))

    if password != confirm_pw:
        flash("Passwords do not match!")
        return redirect(url_for('main_page'))

    conn = get_db_connection()

    # 2. Проверки
    # Используем .fetchone(), он вернет строку (кортеж) или None
    inv_check = conn.execute('SELECT * FROM invites WHERE code = ? AND status = "active"', (invite,)).fetchone()
    user_check = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
    email_check = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()

    conn.close()

    # 3. Логика проверки результатов
    if not inv_check:
        # Для отладки в консоли:
        print(f"DEBUG: Инвайт '{invite}' не найден в базе или не активен")
        flash("The invite is invalid or already used!")
        return redirect(url_for('main_page'))
    
    if user_check:
        flash("Этот ник уже занят!")
        return redirect(url_for('main_page'))

    if email_check:
        flash("This email is already registered!")
        return redirect(url_for('main_page'))
    
    if len(password) < 8:
        flash("Password must be at least 8 characters!")
        return redirect(url_for('main_page'))

    # Генерируем код
    code = str(random.randint(100000, 999999))

    session['temp_user_data'] = {
        'username': username,
        'email': email,
        'password_hash': generate_password_hash(password),
        'invite': invite,
        'browser_id': browser_id,
        'verification_code': code
    }

    if send_verification_code(email, code):
        print(f"📧 Код {code} отправлен на {email}")
        return redirect(url_for('verify_page'))
    else:
        flash("Failed to send email. Check your settings.")
        return redirect(url_for('main_page'))

@app.route('/capcha')
def verify_page():
    return render_template("verify_email.html")

@app.route('/verify', methods=['POST'])
def verify_process():
    entered_code = request.form.get('user_code')
    temp_data = session.get('temp_user_data')

    if temp_data and entered_code == temp_data['verification_code']:
        try:
            conn = get_db_connection()
            cursor = conn.cursor()

            # 1. Записываем пользователя (УБРАЛИ invite_used и browser_id, так как их нет в твоем init_db)
            # Теперь здесь ровно 7 колонок (id пропущена, так как она AUTOINCREMENT)
            cursor.execute('''
                INSERT INTO users (username, email, password_hash, role, status, sub_days)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                temp_data['username'], 
                temp_data['email'], 
                temp_data['password_hash'], 
                'User', 
                'Active', 
                '30'
            ))
            
            new_uid = cursor.lastrowid

            # 2. А вот здесь инвайт СГОРАЕТ. Это работает, так как в таблице invites колонка status есть!
            cursor.execute('''
                UPDATE invites 
                SET status = 'used' 
                WHERE code = ?
            ''', (temp_data['invite'],))
            
            conn.commit()
            conn.close()

            session.pop('temp_user_data', None) 
            
            session['user_id'] = str(new_uid)
            session['username'] = temp_data['username']
            session['role'] = 'User'
            session['status'] = 'Active'
            session['sub_days'] = '30'
            
            return redirect(url_for('obsidian', id=new_uid))
            
        except Exception as e:
            print(f"❌ Критическая ошибка при записи в БД: {e}")
            flash("Ошибка базы данных.")
            return redirect(url_for('main_page'))
    else:
        flash("Invalid verification code!")
        return redirect(url_for('verify_page'))


app.permanent_session_lifetime = timedelta(days=7)
@app.route('/login')
def login_page(): 
    return render_template('login.html')


@app.route('/logout')
def logout():
    # 1. Полностью уничтожаем данные сессии
    session.clear()
    
    # 2. Опционально: добавляем сообщение, что выход успешен
    flash("You are logged out", "info")
    
    # 3. Перенаправляем именно на страницу входа
    return redirect(url_for('login_page'))

@app.route('/login_action', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
    conn.close()

    if user:
        if check_password_hash(user['password_hash'], password):
            
            # === ПРОВЕРКА НА БАН ===
            if user['status'] == 'banned':
                print(f"🚫 ACCESS DENIED: User {username} is BANNED.")
                flash("You have been BANNED!")
                return redirect(url_for('login_page'))
            
            # Если не забанен — пускаем дальше
            session.permanent = True
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            session['status'] = user['status']
            
            return redirect(url_for('obsidian', id=user['id']))
        else:
            print("❌ Invalid Password")
    else:
        print("❌ User not found")

    flash("Invalid username or password!")
    return redirect(url_for('login_page'))


from datetime import datetime

@app.route('/index')
def obsidian():
    user_id = session.get('user_id')
    
    # 1. Проверка авторизации
    if not user_id:
        return redirect(url_for('main_page'))

    # 2. Одно подключение к БД
    conn = get_db_connection()
    
    # Получаем данные текущего пользователя
    user = conn.execute(
        'SELECT * FROM users WHERE id = ?', 
        (user_id,)
    ).fetchone()

    if not user:
        conn.close()
        session.clear()
        return redirect(url_for('main_page'))

    # Тянем заказы ТЕКУЩЕГО пользователя для таблицы
    orders = conn.execute('''
        SELECT orders.*, users.sub_expiry 
        FROM orders 
        JOIN users ON orders.user_id = users.id 
        WHERE orders.user_id = ? 
        ORDER BY orders.id DESC
    ''', (user_id,)).fetchall()

    # Считаем общую сумму completed заказов СО ВСЕГО СЕРВЕРА прямо в SQL
    total_server_invested = conn.execute('''
        SELECT COALESCE(SUM(total_price), 0) 
        FROM orders 
        WHERE status = 'completed'
    ''').fetchone()[0]

    conn.close()

    # 3. Актуализация сессии
    session['role'] = user['role']
    session['status'] = user['status']
    session['sub_days'] = user['sub_days']

    # 4. Передача данных в шаблон
    return render_template(
        "obsidian.html", 
        name=user['username'], 
        role=user['role'], 
        status=user['status'], 
        sub_days=user['sub_days'], 
        expiry=user['sub_expiry'],
        uid=user_id,
        orders=orders,
        total_invested=total_server_invested, # Вся сумма completed-заказов со всего сервера
        current_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    )

@app.route('/info')
def info_page():
    return render_template("info.html",role=session.get('role'))
@app.route('/<int:user_id>/purchase')
def purchase_page(user_id):
    # 1. Проверка сессии (безопасность)
    # Если юзер пытается зайти в чужой ID или не залогинен
    if 'user_id' not in session or session.get('user_id') != user_id:
        flash("Access denied.")
        return redirect(url_for('login_page'))

    # 2. Берем данные из базы по user_id из ссылки
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    conn.close()

    if not user:
        return "User not found", 404

    return render_template("purchase.html", 
                           uid=user['id'], 
                           username=user['username'], 
                           role=session.get('role'))

@app.route('/upload_avatar', methods=['POST'])
def upload_avatar():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    file = request.files.get('avatar_file')
    if file and allowed_file(file.filename):
        # Генерируем имя: id_пользователя.png
        ext = file.filename.rsplit('.', 1)[1].lower()
        filename = secure_filename(f"avatar_{session['user_id']}.{ext}")
        file_path = os.path.join(AVATAR_FOLDER, filename)
        file.save(file_path)

        # Обновляем путь в БД
        conn = get_db_connection()
        conn.execute('UPDATE users SET avatar = ? WHERE id = ?', 
                     (filename, session['user_id']))
        conn.commit()
        conn.close()
        
        flash('Avatar updated!', 'success')
    
    return redirect(url_for('public_profile', user_id=session['user_id']))

from datetime import datetime

@app.route('/profile/<int:user_id>')
def public_profile(user_id):
    conn = get_db_connection()
    
    # 1. Получаем данные самого юзера
    user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    if not user:
        conn.close()
        return "Пользователь не найден", 404

    # 2. Получаем список уникальных купленных продуктов
    product_rows = conn.execute('''
        SELECT DISTINCT plan_name 
        FROM orders 
        WHERE user_id = ? AND status = "completed"
    ''', (user_id,)).fetchall()
    
    products = [row['plan_name'] for row in product_rows]

    # 3. Считаем общее количество успешных покупок и суммарную стоимость вложений
    stats = conn.execute('''
        SELECT 
            COUNT(*) as orders_count,
            COALESCE(SUM(total_price), 0) as total_invested
        FROM orders 
        WHERE user_id = ? AND status = "completed"
    ''', (user_id,)).fetchone()

    orders_count = stats['orders_count']
    user_total_invested = stats['total_invested']

    conn.close()

    is_own = (session.get('user_id') == user_id)

    return render_template(
        "profile.html", 
        user=user, 
        products=products, 
        orders_count=orders_count,
        user_total_invested=user_total_invested, # ПЕРЕДАЕМ СУММУ ВЛОЖЕНИЙ
        role=session.get('role'),
        is_own=is_own
    )


@app.route('/update_privacy', methods=['POST'])
def update_privacy():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('main_page'))
    
    conn = get_db_connection()
    # Инвертируем флаг hide_invested (0 -> 1, 1 -> 0)
    conn.execute('UPDATE users SET hide_invested = 1 - COALESCE(hide_invested, 0) WHERE id = ?', (user_id,))
    conn.commit()
    conn.close()
    
    return redirect(url_for('public_profile', user_id=user_id))

online_users = {} # {user_id: username}

def emit_online_list():
    # Создаем словарь, где ключом будет ID пользователя. 
    # Это гарантирует, что один человек не появится в списке дважды.
    unique_users = {}
    
    for sid, data in online_users.items():
        uid = data.get('id')
        if uid:
            unique_users[uid] = {
                "username": data.get('username'),
                "id": uid,
                "role": data.get('role', 'User')
            }
    
    # Отправляем только уникальные значения
    socketio.emit('update_online_list', list(unique_users.values()))

# 2. Исправляем handle_connect (добавляем auth=None)
@socketio.on('connect')
def handle_connect(auth=None):
    uid = session.get('user_id')
    uname = session.get('username')
    
    if uid and uname:
        # Проверяем роль в сессии, если нет — лезем в БД
        urole = session.get('role')
        if not urole:
            conn = get_db_connection()
            user_data = conn.execute('SELECT role FROM users WHERE id = ?', (uid,)).fetchone()
            conn.close()
            urole = user_data['role'] if user_data else 'User'
            session['role'] = urole # Сохраняем в сессию на будущее

        # Сохраняем в онлайн-словарь (используем uid как ключ для избежания дублей)
        # request.sid — это ID конкретной вкладки
        online_users[request.sid] = {
            "username": uname, 
            "id": uid, 
            "role": str(urole).upper() # Приводим к верхнему регистру для надежности
        }
        
        print(f"DEBUG: {uname} connected with role: {urole}")
        emit_online_list()

@socketio.on('disconnect')
def handle_disconnect():
    if request.sid in online_users:
        user = online_users.pop(request.sid)
        print(f"<<< {user['username']} вышел")
        emit_online_list()

# Роут чата с динамическим ID
@app.route('/<int:user_id>/general')
def chat_page(user_id):
    if 'user_id' not in session:
        return redirect(url_for('main_page'))
    
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (session.get('user_id'),)).fetchone()
    
    if str(session.get('user_id')) != str(user_id):
        conn.close()
        return redirect(url_for('chat_page', user_id=session.get('user_id')))

    session['role'] = user['role']

    # ДОБАВИЛИ: strftime('%H:%M', timestamp) AS time
    # Это вытащит время в формате 21:45 прямо из колонки timestamp
    db_messages = conn.execute('''
        SELECT user, msg, role, color, strftime('%H:%M', timestamp) as time 
        FROM messages 
        ORDER BY id DESC LIMIT 50
    ''').fetchall()
    last_post = conn.execute('SELECT * FROM announcements ORDER BY id DESC LIMIT 1').fetchone()
    
    conn.close()

    history = db_messages[::-1]

    return render_template('chat.html', 
                           username=session.get('username'), 
                           uid=user_id,
                           history=history, 
                           role=session.get('role'),
                           user=user['username'],
                           online_count=len(online_users),
                           last_post = last_post)
 
# Обработка сообщений чата
import datetime # Не забудь импортировать в начале файла

@socketio.on('send_message')
def handle_message(data):
    if 'user_id' not in session:
        return False 

    username = session.get('username', 'Guest')
    msg = escape(data.get('message', '')).strip()
    role = session.get('role', 'User') 
    
    if msg and len(msg) <= 500:
        # Цвета
        color = 'cyan' if role == 'Admin' else ('red' if role == 'Coder' else 'gold' if role == 'Owner' else 'chartreuse')
        
        # Генерируем текущее время для отправки в сокеты
        now = datetime.now()
        current_time = now.strftime("%H:%M")

        conn = get_db_connection()
        # В INSERT мы обычно передаем DEFAULT для timestamp, 
        # но если колонка не заполняется сама, пишем datetime.now()
        conn.execute('INSERT INTO messages (user, msg, role, color) VALUES (?, ?, ?, ?)', 
                     (username, msg, role, color))
        conn.commit()
        conn.close()

        # Отправляем сообщение + время (time)
        emit('receive_message', {
            'user': username, 
            'msg': msg, 
            'role': role, 
            'color': color,
            'time': current_time # Добавили поле времени
        }, broadcast=True)

@app.route('/configs')
def configs_page():
    if 'user_id' not in session:
        return redirect(url_for('main_page'))
        
    conn = get_db_connection()
    # Соединяем таблицы, чтобы у каждого конфига был автор и его аватарка
    configs = conn.execute('''
        SELECT 
            c.*, 
            u.username as author_name, 
            u.avatar 
        FROM configs c
        LEFT JOIN users u ON c.author_id = u.id
        ORDER BY c.id DESC
    ''').fetchall()
    conn.close()
    
    return render_template('configs.html', configs=configs)

@app.route('/announcements')
def all_announcements():
    if 'user_id' not in session:
        return redirect(url_for('main_page'))
        
    conn = get_db_connection()
    # JOIN связывает author_id из постов с id из таблицы users
    posts = conn.execute('''
        SELECT 
            a.*, 
            u.avatar,
            u.role, 
            strftime("%d.%m.%Y %H:%M", a.date) as full_date 
        FROM announcements a
        JOIN users u ON a.author_id = u.id
        ORDER BY a.id DESC
    ''').fetchall()
    conn.close()
    
    user_role = session.get('role', 'User')
    can_post = user_role in ['Owner', 'Coder']
    
    return render_template('announcements.html', posts=posts, can_post=can_post, role=session.get('role'))


# --- 3.2. Обработка создания нового поста (Только Owner/Coder) ---
@app.route('/announcements/create', methods=['POST'])
def create_post():
    if 'user_id' not in session or session.get('role') not in ['Owner', 'Coder']:
        abort(403) # Доступ запрещен

    content = request.form.get('content', '').strip()
    title = request.form.get('title', '').strip() # Заголовок опционален
    file = request.files.get('image')
    
    if not content and not file:
        flash('Пост не может быть пустым (нужен текст или фото).', 'error')
        return redirect(url_for('all_announcements'))

    image_url = None

    # Обработка загрузки файла
    if file and allowed_file(file.filename):
        # Генерируем уникальное имя файла, чтобы избежать совпадений
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        unique_filename = f"{session['user_id']}_{timestamp}_{filename}"
        
        # Сохраняем файл
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        file.save(file_path)
        
        # Записываем путь для базы данных
        image_url = f"/{UPLOAD_FOLDER}/{unique_filename}"

    # Сохраняем в БД
    conn = get_db_connection()
    conn.execute('''
        INSERT INTO announcements (title, content, image_url, author_id, author) 
        VALUES (?, ?, ?, ?, ?)
    ''', (title, content, image_url, session['user_id'], session['username']))
    conn.commit()
    conn.close()
    
    flash('Пост успешно опубликован!', 'success')
    return redirect(url_for('all_announcements'))

@app.route('/api/search')
def api_search():
    if 'user_id' not in session:
        return jsonify([]) # Пустой список, если не залогинен

    query = request.args.get('query', '')
    if len(query) < 2: # Начинаем поиск от 2-х символов
        return jsonify([])

    conn = get_db_connection()
    # Берем ID, Ник и Роль
    users = conn.execute("SELECT id, username, role FROM users WHERE username LIKE ? LIMIT 5", 
                         ('%' + query + '%',)).fetchall()
    conn.close()

    # Превращаем результат в список словарей
    results = [{"id": u["id"], "username": u["username"], "role": u["role"]} for u in users]
    return jsonify(results)

@app.route('/checkout/<string:plan>')
def final_checkout(plan):
    if 'user_id' not in session:
        return redirect(url_for('login_page'))

    conn = get_db_connection()
    # Ищем тариф в базе по его техническому имени (plan_id)
    plan_data = conn.execute('SELECT * FROM plans WHERE plan_id = ?', (plan,)).fetchone()
    conn.close()

    # Если такой тариф не найден в базе данных
    if plan_data is None:
        return "Ошибка: Тариф не найден", 404

    # Теперь берем данные прямо из строки базы
    return render_template("checkout.html", 
                           plan=plan, 
                           display_name=plan_data['display_name'],
                           price=plan_data['price'], 
                           days=plan_data['days'],
                           role=session.get('role'),
                           username=session.get('username'))

@app.route('/api/check_promo')
def check_promo():
    code = request.args.get('code', '').strip().upper()
    
    conn = get_db_connection()
    # Ищем код, у которого количество применений больше 0
    promo = conn.execute('SELECT * FROM promocodes WHERE code = ? AND uses_left > 0', (code,)).fetchone()
    conn.close()

    if promo:
        return jsonify({
            'success': True,
            'discount': promo['discount_percent']
        })
    else:
        return jsonify({
            'success': False,
            'message': 'promo not found'
        })



@app.route('/api/create_order', methods=['POST'])
def create_order():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Auth required'}), 401

    try:
        data = request.get_json()
        plan_id = data.get('plan')
        user_id = session.get('user_id')

        conn = get_db_connection()
        
        # 1. ПРОВЕРКА: Нет ли уже активного заказа? (Race Condition Protection)
        

        # 2. ПРОВЕРКА: Существует ли такой план и какая у него РЕАЛЬНАЯ цена?
        # Никогда не верь цене, которая пришла с фронтенда!
        plan_info = conn.execute('SELECT * FROM plans WHERE plan_id = ?', (plan_id,)).fetchone()
        if not plan_info:
            conn.close()
            return jsonify({'success': False, 'message': 'Invalid plan'}), 400

        real_price = plan_info['price']

        # 3. ЗАПИСЬ
        conn.execute('''
            INSERT INTO orders (user_id, username, plan_name, total_price, status) 
            VALUES (?, ?, ?, ?, 'pending')
        ''', (user_id, session.get('username'), plan_id, real_price))
        
        conn.commit()
        conn.close()
        return jsonify({'success': True})
        
    except Exception as e:
        return jsonify({'success': False, 'error': 'Server error'}), 500

@app.route('/checkout/<plan_name>')
def checkout(plan_name):
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login'))

    # Получаем цену (твой существующий код)
    # ... price = ... 

    conn = get_db_connection()
    # Ищем ПОСЛЕДНИЙ заказ этого юзера со статусом 'pending'
    active_order = conn.execute('''
        SELECT * FROM orders 
        WHERE user_id = ? AND status = 'pending' 
        ORDER BY created_at DESC LIMIT 1
    ''', (user_id,)).fetchone()
    conn.close()

    # Передаем переменную active_order в шаблон
    return render_template('checkout.html', 
                           plan=plan_name, 
                           price=price, 
                           uid=user_id, 
                           active_order=active_order)

@app.route('/admin', methods=['GET', 'POST'])
def admin_panel():
    # Проверка авторизации
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Получаем роль
    user_role = session.get('role')

    # ЗАЩИТА: Если вдруг в сессии роль потерялась, тянем из базы
    if not user_role:
        conn = get_db_connection()
        user = conn.execute('SELECT role FROM users WHERE id = ?', (session['user_id'],)).fetchone()
        conn.close()
        if user:
            session['role'] = user['role']
            user_role = user['role']

    # Проверка прав
    if user_role not in ['Coder', 'Owner','Admin']:
        return redirect(url_for('obsidian', id=session.get('user_id')))

    return render_template("admin.html", role=user_role)


@app.route('/admin/orders')
def admin_orders():
    # Проверка прав (обязательно!)
    if session.get('role') not in ['Coder', 'Owner','Admin']:
        print("DEBUG: Отказ в доступе, роль:", session.get('role'))
        return redirect('/')

    try:
        conn = get_db_connection()
        # Проверь, что таблица orders точно существует!
        orders = conn.execute('''
    SELECT orders.*, users.username, users.role 
    FROM orders 
    JOIN users ON orders.user_id = users.id 
    ORDER BY orders.id DESC
''').fetchall()
        conn.close()
        
        print(f"DEBUG: Найдено заказов: {len(orders)}")
        
        # ВАЖНО: Убедись, что тут есть return и имя файла совпадает!
        return render_template("admin_orders.html", orders=orders, role = session.get('role'))
        
    except Exception as e:
        print(f"DEBUG: Ошибка в базе данных: {e}")
        return f"Ошибка БД: {e}" # Выведет ошибку прямо на экран вместо белого фона

from datetime import datetime, timedelta
import random
import string

# Та самая функция для твоего формата
def generate_order_key():
    letters = string.ascii_lowercase
    digits = string.digits
    # Блок (11 букв) - (5 цифр) - (11 букв)
    part1 = ''.join(random.choice(letters) for _ in range(11))
    part2 = ''.join(random.choice(digits) for _ in range(5))
    part3 = ''.join(random.choice(letters) for _ in range(11))
    return f"{part1}-{part2}-{part3}"

@app.route('/admin/approve/<int:order_id>')
def approve_order(order_id):
    if session.get('role') not in ['Coder', 'Owner','Admin']:
        return redirect('/')
    
    order_key = generate_order_key()




    conn = get_db_connection()
    order = conn.execute('SELECT * FROM orders WHERE id = ?', (order_id,)).fetchone()
    
    if order and order['status'] == 'pending':
        user_id = order['user_id']
        plan_name = order['plan_name'] 

        # 1. Узнаем, сколько дней дает план из таблицы plans
        plan_info = conn.execute('SELECT days FROM plans WHERE plan_id = ?', (plan_name,)).fetchone()
        
        if plan_info:
            days_to_add = plan_info['days']
            
            # 2. Вычисляем дату окончания ТЕКУЩЕГО заказа
            # Отсчет идет от момента подтверждения админом
            now = datetime.now()
            new_end = now + timedelta(days=days_to_add)
            new_end_str = new_end.strftime('%Y-%m-%d %H:%M:%S')

            # 3. Обновляем ТОЛЬКО таблицу orders
            # Добавляем expire_date конкретно этому заказу
            try:
                conn.execute('''
                    UPDATE orders 
                    SET status = "completed", 
                        expire_date = ?, 
                        order_key = ? 
                    WHERE id = ?
                ''', (new_end_str, order_key, order_id))
                
                
                # Если ты все еще хочешь хранить "самую позднюю" дату в юзере (опционально)
                conn.execute('UPDATE users SET sub_expiry = ? WHERE id = ?', (new_end_str, user_id))
                
                conn.commit()
                print(f"SUCCESS: Order #{order_id} approved. Key: {order_key}")
            except Exception as e:
                print(f"DATABASE ERROR: {e}")
                # Если колонки expire_date нет, база выдаст ошибку здесь
        else:
            print(f"ERROR: Plan {plan_name} not found in database!")

    conn.close()
    return redirect(url_for('admin_orders'))

from datetime import datetime



@app.route('/admin/users')
def admin_users():
    if session.get('role') not in ['Coder', 'Owner','Admin']:
        return redirect('/')
    
    search_query = request.args.get('search', '')
    conn = get_db_connection()
    # Получаем текущее время как объект для сравнения
    now_obj = datetime.now()
    current_time_str = now_obj.strftime('%Y-%m-%d %H:%M:%S')
    
    # Сложный запрос: берем юзера и дату окончания его ПОСЛЕДНЕГО выполненного заказа
    query = '''
        SELECT u.*, 
        (SELECT MAX(expire_date) FROM orders o WHERE o.user_id = u.id AND o.status = "completed") as last_sub_date
        FROM users u
    '''
    
    if search_query:
        users_raw = conn.execute(query + " WHERE u.username LIKE ? ORDER BY u.id DESC", 
                                 ('%' + search_query + '%',)).fetchall()
    else:
        users_raw = conn.execute(query + " ORDER BY u.id DESC").fetchall()
    
    conn.close()

    # Обрабатываем данные перед отправкой в шаблон
    users = []
    for row in users_raw:
        user_dict = dict(row)
        is_active = False
        
        # Проверяем реальную дату из последнего заказа
        expiry_str = user_dict.get('last_sub_date')
        if expiry_str:
            try:
                expiry_date = datetime.strptime(expiry_str, '%Y-%m-%d %H:%M:%S')
                if expiry_date > now_obj:
                    is_active = True
            except:
                is_active = False
        
        # Записываем результат проверки прямо в словарь юзера
        user_dict['has_active_sub'] = is_active
        users.append(user_dict)
    
    return render_template('admin_users.html', 
                           users=users, 
                           search_query=search_query, 
                           current_time=current_time_str,
                           role = session.get('role'))

@app.route('/admin/user_action/<int:user_id>/<action>')
def user_action(user_id, action):
    # 1. Глобальная проверка прав
    current_role = session.get('role')
    current_id = session.get('user_id')
    
    if current_role not in ['Owner', 'Coder', 'Admin']:
        return redirect('/')
    
    # 2. ЗАЩИТА ОТ САМОБАНА И ПРАВКИ СЕБЯ
    if user_id == current_id:
        return redirect(f'/profile/{user_id}')
    
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    
    if not user:
        conn.close()
        return redirect(url_for('admin_users'))

    # ЗАЩИТА: Нельзя банить Овнера или менять ему роль (даже если это делает другой админ)
    if user['role'] == 'Owner':
        conn.close()
        return redirect(url_for('admin_users'))

    if action == 'ban':
        # Переключаем только статус, роль вообще не трогаем
        new_status = 'banned' if user['status'] == 'active' else 'active'
        conn.execute("UPDATE users SET status = ? WHERE id = ?", (new_status, user_id))
    
    elif action == 'toggle_admin':
        # Если юзер обычный — делаем Админом. Если Админ — делаем Юзером.
        # Если Coder — роль не трогаем, чтобы не сбить права.
        if user['role'] == 'User':
            new_role = 'Admin'
        elif user['role'] == 'Admin':
            new_role = 'User'
        else:
            new_role = user['role'] # Оставляем как есть (для Coder/Owner)
            
        conn.execute("UPDATE users SET role = ? WHERE id = ?", (new_role, user_id))
    
    conn.commit()
    conn.close()
    return redirect(url_for('admin_users'))

@app.route('/admin/invites', methods=['GET', 'POST'])
def admin_invites():
    if session.get('role') not in ['Owner', 'Coder','Admin']:
        return redirect('/')
    def generate_random_code():
    # Набор символов (убрали похожие 0/O, 1/I для удобства)
        chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        
        # Генерируем 4 блока по 4 символа
        blocks = []
        for _ in range(4):
            block = ''.join(random.choice(chars) for _ in range(4))
            blocks.append(block)
        
        # Соединяем блоки дефисом: XXXX-XXXX-XXXX-XXXX
        return "-".join(blocks)


    conn = get_db_connection()
    if request.method == 'POST':
        new_invite =  generate_random_code()
        conn.execute('INSERT INTO invites (code, status) VALUES (?, ?)', (new_invite, 'active'))
        conn.commit()
        return redirect(url_for('admin_invites'))
    invite_reqs = conn.execute('SELECT * FROM invite_requests ORDER BY id DESC').fetchall()
    invites = conn.execute('SELECT * FROM invites ORDER BY id DESC').fetchall()
    conn.close()
    return render_template('admin_invites.html', invites=invites, requests=invite_reqs, role = session.get('role'))

# --- УПРАВЛЕНИЕ ПРОМОКОДАМИ ---
@app.route('/admin/promocodes', methods=['GET', 'POST'])
def admin_promocodes():
    if session.get('role') not in ['Owner', 'Coder','Admin']:
        return redirect('/')
    



    conn = get_db_connection()
    if request.method == 'POST':
        code = request.form.get('code').upper() 
        discount = int(request.form.get('discount', 10))
        uses = int(request.form.get('uses', 10))
        
        # Простая проверка на дубликат кода
        try:
            discount = int(request.form.get('discount', 10))
            uses = int(request.form.get('uses', 10))
            if discount < 0 or discount > 100: raise ValueError
        except (ValueError, TypeError):
            flash("Invalid input values")
            return redirect(url_for('admin_promocodes'))

    promos = conn.execute('SELECT * FROM promocodes ORDER BY id DESC').fetchall()
    conn.close()
    return render_template('admin_promocodes.html', promos=promos, role = session.get('role'))


import sqlite3
from datetime import datetime
from flask import request

@app.route('/auth.php', methods=['POST', 'GET'])
def loader_authorize():
    key = request.values.get('key', '').strip()
    hwid = request.values.get('hwid', '').strip()

    if not key or not hwid:
        return "ERROR_INVALID_KEY"

    try:
        conn = get_db_connection()
        # Сразу ищем только ТЕ заказы, которые помечены как valid
        cursor = conn.execute("SELECT * FROM orders WHERE order_key = ? AND valid = 'valid' LIMIT 1", (key,))
        row = cursor.fetchone()

        if not row:
            conn.close()
            return "ERROR_INVALID_KEY_OR_EXPIRED"

        # Проверка даты (на случай если крон/воркер еще не пометил как invalid)
        now = datetime.now()
        expiry_date = datetime.strptime(row['expire_date'], '%Y-%m-%d %H:%M:%S')
        
        if expiry_date < now:
            conn.execute("UPDATE orders SET valid = 'invalid' WHERE order_key = ?", (key,))
            conn.commit()
            conn.close()
            return "ERROR_EXPIRED"
        
        delta = expiry_date - now
        days_left = delta.days if delta.days > 0 else 0

        # Привязка HWID (защита от передачи ключа другу)
        if not row['hwid']:
            conn.execute("UPDATE orders SET hwid = ? WHERE order_key = ?", (hwid, key))
            conn.commit()
        elif row['hwid'] != hwid:
            conn.close()
            return "ERROR_HWID_MISMATCH"

        conn.close()
        # Добавляем соль или хеш, чтобы ответ нельзя было легко подделать через Fiddler/Charles
        return f"SUCCESS_LOGIN|/download_payload?key={key}&hwid={hwid}|{row['username']}|{row['user_id']}|{days_left}"

    except Exception as e:
        return "ERROR_DB"

@app.route('/download_payload')
def download_payload():
    key = request.args.get('key')
    hwid = request.args.get('hwid')
    
    print(f"\n[DEBUG] === XOR Шифрование для файлов в хранилище ===")
    
    try:
        # 1. Проверка в БД
        conn = sqlite3.connect('obsidianweb.db') 
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM orders WHERE order_key = ? AND hwid = ? AND valid = 'valid'", (key, hwid))
        row = cursor.fetchone()
        conn.close()

        if not row:
            return "ERR_ACCESS_DENIED", 403

        # 2. Поиск файлов
        if not os.path.exists(SH_STORAGE_DIR):
            return "ERR_STORAGE_NOT_FOUND", 404

        # Берем только файлы (игнорируем папки) и, например, только .sh
        files = [f for f in os.listdir(SH_STORAGE_DIR) if os.path.isfile(os.path.join(SH_STORAGE_DIR, f)) and f.endswith('.sh')]

        if not files:
            print("[DEBUG] Папка пуста или нет .sh файлов!")
            return "ERR_FILE_NOT_FOUND", 404

        # Берем первый доступный файл
        target_file = files[0]
        file_path = os.path.join(SH_STORAGE_DIR, target_file)
        print(f"[DEBUG] Работаем с файлом: {target_file}")

        # 3. Читаем и шифруем
        with open(file_path, 'rb') as f:
            original_data = f.read()
        
        # XOR Шифрование
        encrypted_data = bytes([b ^ XOR_KEY for b in original_data])
        
        print(f"[DEBUG] Шифрование завершено. Отправка {len(encrypted_data)} байт.")
        
        # 4. Отправка
        return Response(
            encrypted_data,
            mimetype='application/octet-stream',
            headers={
                # Отдаем под тем же именем, которое нашли, или фиксированным q.sh
                "Content-Disposition": f"attachment; filename={target_file}",
                "Cache-Control": "no-cache"
            }
        )

    except Exception as e:
        print(f"[ERROR] {e}")
        return "ERR_SERVER_INTERNAL", 500
    

import threading
import queue
import json
import time

# --- 1. ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ (В начало файла) ---
_radar_data = {"enemies": [], "map": "unknown", "ts": 0}
_radar_lock = threading.Lock()
_sse_clients = []
_sse_lock = threading.Lock()

# --- 2. ФУНКЦИЯ РАССЫЛКИ (SSE) ---
def _push_sse(data):
    msg = f"data: {json.dumps(data)}\n\n"
    with _sse_lock:
        for q in _sse_clients[:]:
            try:
                q.put_nowait(msg)
            except queue.Full:
                pass

@app.route('/cloud_radar')
def radar_page():
    if 'user_id' not in session:
        return redirect(url_for('login_page'))

    return render_template('cloud_radar.html',role = session.get('role'))

# Прием данных от чита (ТВОЙ ЗАПРОС)
@app.route("/update", methods=["POST"])
def update():
    print("!!! ПРИШЕЛ ЗАПРОС ОТ ЧИТА !!!")
    try:
        # force=True поможет, если чит не шлет правильный заголовок JSON
        data = request.get_json(force=True, silent=True) or {}
    except Exception:
        return "bad request", 400

    with _radar_lock:
        _radar_data["map"] = data.get("map", "unknown")
        _radar_data["enemies"] = data.get("enemies", [])
        _radar_data["ts"] = time.time()
    
    # Сразу толкаем данные всем, кто открыл страницу радара
    _push_sse(_radar_data)
    return "ok"

# Стрим для фронтенда (SSE)
@app.route("/radar/stream")
def radar_stream():
    q = queue.Queue(maxsize=10)
    with _sse_lock:
        _sse_clients.append(q)

    def generate():
        try:
            # Сразу шлем текущее состояние при подключении
            with _radar_lock:
                yield f"data: {json.dumps(_radar_data)}\n\n"
            while True:
                msg = q.get() # Ждем новые данные от _push_sse
                yield msg
        finally:
            with _sse_lock:
                if q in _sse_clients:
                    _sse_clients.remove(q)

    return Response(generate(), mimetype="text/event-stream", 
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

# Твой старый роут (на всякий случай, если JS использует fetch)
@app.route('/get_coords')
def get_coords():
    with _radar_lock:
        return jsonify(_radar_data)

# Пути к папка

@app.route('/admin/files', methods=['GET', 'POST'])
def admin_files():
    if session.get('role') not in ['Owner', 'Coder']:
        return redirect('/')

    if request.method == 'POST':
        file = request.files.get('file')
        build_type = request.form.get('build_type') 
        
        if file and file.filename != '':
            # ЛОГИКА ВЫБОРА ИЗ ТРЕХ ПАПОК
            if build_type == 'internal':
                target_dir = INTERNAL_DIR
            elif build_type == 'external':
                target_dir = EXTERNAL_DIR
            elif build_type == 'sh':
                target_dir = SH_STORAGE_DIR
            else:
                target_dir = SH_STORAGE_DIR # Для остальных файлов
            
            if not os.path.exists(target_dir):
                os.makedirs(target_dir)
                
            file.save(os.path.join(target_dir, file.filename))
            print(f"[DEBUG] Файл {file.filename} улетел в {target_dir}")
            return redirect(url_for('admin_files'))

    # Собираем списки из всех трех директорий
    internal_files = os.listdir(INTERNAL_DIR) if os.path.exists(INTERNAL_DIR) else []
    external_files = os.listdir(EXTERNAL_DIR) if os.path.exists(EXTERNAL_DIR) else []
    sh_files = os.listdir(SH_STORAGE_DIR) if os.path.exists(SH_STORAGE_DIR) else []
    
    return render_template('admin_files.html', 
                           internal_files=internal_files, 
                           external_files=external_files,
                           sh_files=sh_files, # ПЕРЕДАЕМ ТРЕТИЙ СПИСОК
                           role=session.get('role'))


@app.route('/delete-file/<filename>/<folder>')
def delete_file(filename, folder):
    if session.get('role') not in ['Owner', 'Coder']:
        return redirect('/')

    # Очищаем имя файла от попыток выйти из папки (удаляем ../ и т.д.)
    filename = secure_filename(filename)
    
    dirs = {
        'internal': INTERNAL_DIR,
        'external': EXTERNAL_DIR,
        'sh': SH_STORAGE_DIR
    }
    
    target_dir = dirs.get(folder)
    if target_dir:
        file_path = os.path.join(target_dir, filename)
        if os.path.exists(file_path):
            os.remove(file_path)
            
    return redirect(url_for('admin_files'))
        
@app.route('/product/<int:order_id>')
def open_product(order_id):
    if 'user_id' not in session:
        return redirect(url_for('login_page'))

    conn = get_db_connection()
    order = conn.execute('SELECT * FROM orders WHERE id = ?', (order_id,)).fetchone()

    if not order:
        conn.close()
        return "Заказ не найден", 404

    if order['user_id'] != session.get('user_id') and session.get('role') not in ['Coder', 'Owner']:
        conn.close()
        return redirect(url_for('my_purchases'))

    # --- ЛОГИКА ПРОВЕРКИ VALID / INVALID ---
    is_active = False
    expiry_str = order['expire_date']
    current_status = order['valid'] # берем текущее значение из базы

    if expiry_str:
        try:
            expiry_date = datetime.strptime(expiry_str, '%Y-%m-%d %H:%M:%S')
            if expiry_date > datetime.now():
                is_active = True
                new_status = "valid"
                print("valid")
            else:
                is_active = False
                new_status = "invalid"
                print("invalid")
            
            # Если статус в базе не совпадает с реальным временем — обновляем базу
            if current_status != new_status:
                conn.execute('UPDATE orders SET valid = ? WHERE id = ?', (new_status, order_id))
                conn.commit()
                current_status = new_status # обновляем переменную для шаблона
                
        except Exception as e:
            print(f"Ошибка даты: {e}")
            is_active = False


    available_files = []
    plan_name_lower = order['plan_name']

    if 'internal' in plan_name_lower:
        p_type = 'internal'
        folder = INTERNAL_DIR
        print(f"odaeb {p_type}")
    elif 'external' in plan_name_lower:
        p_type = 'external'
        folder = EXTERNAL_DIR
        print(f"odaeb {p_type}")
    elif 'rage' in plan_name_lower:
        p_type = 'internal'
        folder = ARNOLD_DIR
    elif 'legit' in plan_name_lower:
        p_type = 'external'
        folder = ARNOLD_DIR
    elif 'radar' in plan_name_lower: # ДОБАВЛЯЕМ ЭТОТ БЛОК
        p_type = 'radar'
        folder = None # Файлы не нужны, это веб-сервис
    else:
        p_type = None
        folder = None
    if is_active and folder and os.path.exists(folder):
        available_files = os.listdir(folder)
        print(f"[DEBUG] Нашли файлы: {available_files}")

    conn.close()

    return render_template("product_page.html", 
                           product=order['plan_name'], 
                           expiry=order['expire_date'], 
                           is_active=is_active,
                           order_key=order['order_key'],
                           valid_status=current_status,
                           files=available_files, # Передаем список файлов
                           plan_type=p_type,
                           role = session.get('role'))

@app.route('/download/<build_type>/<filename>')
def download_file(build_type, filename):
    if 'user_id' not in session:
        return redirect(url_for('login_page'))

    filename = secure_filename(filename) # ОБЯЗАТЕЛЬНО
    user_role = session.get('role')
    
    if user_role in ['Owner', 'Coder']:
        folder = INTERNAL_DIR if build_type == 'internal' else EXTERNAL_DIR
        return send_from_directory(folder, filename)

    # Проверка подписки
    search_term = 'internal' if build_type == 'internal' else 'external'
    conn = get_db_connection()
    order = conn.execute('''
        SELECT id FROM orders 
        WHERE user_id = ? AND LOWER(plan_name) LIKE ? AND valid = 'valid'
    ''', (session['user_id'], f'%{search_term}%')).fetchone()
    conn.close()

    if not order:
        return "Access Denied", 403

    folder = INTERNAL_DIR if build_type == 'internal' else EXTERNAL_DIR
    
    # ПРОВЕРКА: существует ли файл вообще в этой папке?
    if not os.path.exists(os.path.join(folder, filename)):
        return "File not found", 404

    return send_from_directory(folder, filename)


@app.route('/buy-invite')
def buy_invite_page():
    # Эту страницу может видеть любой, даже не залогиненный
    return render_template('buy_invite.html')

@app.route('/save_invite_request', methods=['POST'])
def save_invite_request():
    email = request.json.get('email')
    conn = get_db_connection()
    conn.execute('INSERT INTO invite_requests (email) VALUES (?)', (email,))
    conn.commit()
    conn.close()
    return {"status": "ok"}

@app.route('/send_invite_to_user/<int:req_id>', methods=['POST'])
def send_invite_to_user(req_id):
    # 1. Проверка прав доступа
    if session.get('role') not in ['Owner', 'Coder']:
        return redirect('/')

    # 2. Получаем введенный тобой код из формы
    manual_code = request.form.get('manual_code')

    conn = get_db_connection()
    
    # 3. Достаем email покупателя, чтобы знать, куда отправлять
    req = conn.execute('SELECT email FROM invite_requests WHERE id = ?', (req_id,)).fetchone()

    if req and manual_code:
        # 4. МАГИЯ: Отправляем письмо через твой sender.py
        # Функция вернет True, если письмо ушло, или False, если ошибка
        email_sent = send_verification_code(req['email'], manual_code)
        
        if email_sent:
            # 5. Если почта доставлена, сохраняем код в таблицу рабочих инвайтов
            conn.execute('INSERT OR IGNORE INTO invites (code, status) VALUES (?, ?)', 
                         (manual_code, 'unused'))
            
            # 6. Обновляем статус в таблице запросов (чтобы в админке стало "Выдан ✅")
            conn.execute('UPDATE invite_requests SET status = ? WHERE id = ?', 
                         ('sent', req_id))
            
            conn.commit()
            print(f"✅ Успех: Код {manual_code} отправлен на {req['email']} и активирован.")
        else:
            # Если почта не ушла (например, нет интернета или пароль приложения неверный)
            # База не изменится, чтобы ты мог попробовать нажать еще раз
            print(f"❌ Ошибка: Не удалось отправить письмо на {req['email']}.")

    conn.close()
    return redirect(url_for('admin_invites'))


app.config.update(
    SESSION_COOKIE_HTTPONLY=True,  # Запрещает JavaScript доступ к кукам (защита от XSS)
    SESSION_COOKIE_SECURE=True,    # Куки передаются ТОЛЬКО через HTTPS (Cloudflare это обеспечит)
    SESSION_COOKIE_SAMESITE='Lax', # Защита от CSRF атак
    PERMANENT_SESSION_LIFETIME=timedelta(days=1) # Сессия живет не вечно
)



if __name__ == '__main__':
    # host='0.0.0.0' — чтобы сайт был виден не только тебе, но и в сети
    # port=8080 — стандартный порт для тестов
    # debug=False — КРИТИЧЕСКОЕ условие для безопасности (отключает дебаггер)
    # allow_unsafe_werkzeug=True — нужно, чтобы socketio не ругался на отсутствие gunicorn
    socketio.run(app, host='0.0.0.0', port=8080, debug=True, allow_unsafe_werkzeug=True)
 




