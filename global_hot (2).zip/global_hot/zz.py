import sqlite3

def init_user_configs_table():
    conn = sqlite3.connect('obsidianweb.db')
    cursor = conn.cursor()
    
    # Создаем таблицу с 4 столбцами
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_configs (
            user_id INTEGER PRIMARY KEY,    -- ID создателя (связь с users.id)
            legit_cfg TEXT DEFAULT NULL,    -- Содержимое или имя Legit конфига
            semirage_cfg TEXT DEFAULT NULL, -- Содержимое или имя Semi-Rage конфига
            rage_cfg TEXT DEFAULT NULL,     -- Содержимое или имя Rage конфига
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    conn.commit()
    conn.close()
    print("✅ Таблица user_configs (3 слота) создана")

init_user_configs_table()