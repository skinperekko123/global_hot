import smtplib
import random
from email.mime.text import MIMEText

SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SENDER_EMAIL = "misapetrackov@gmail.com"
SENDER_PASSWORD = "tfae rphy cdwr crmf" # Это НЕ пароль от почты, а специальный код от Google

def send_verification_code(receiver_email, code):
    msg = MIMEText(f"Ваш код подтверждения для Obsidian: {code}")
    msg['Subject'] = 'Email Verification'
    msg['From'] = f'Obsidian <{SENDER_EMAIL}>'
    msg['To'] = receiver_email

    try:
        # Используем порт 587 вместо 465
        server = smtplib.SMTP("smtp.gmail.com", 587, timeout=10)
        server.set_debuglevel(1) # Это включит подробный лог в терминале
        server.starttls()        # Включаем шифрование после подключения
        
        server.login(SENDER_EMAIL, SENDER_PASSWORD)
        server.send_message(msg)
        server.quit()
        
        print(f"✅ Код {code} успешно доставлен на {receiver_email}")
        return True
    except Exception as e:
        print(f"❌ Подробная ошибка: {e}")
        return False
    

